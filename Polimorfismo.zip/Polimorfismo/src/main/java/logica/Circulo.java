/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;
import static java.lang.Math.*;
/**
 *
 * @author Estudiantes
 */
public class Circulo extends Figura {


    public void calcularArea() {
        int radio= this.origen.calcularDistancia(this.fin);
        this.Area= (int) (PI + pow(radio, 2));
    }
    

    public void calcularPerimetro() {
        int radio= this.origen.calcularDistancia(this.fin);
        this.Perimetro= (int) (2 * PI * radio);
    }

    @Override
    public String toString() {
        return "Circulo{" + '}';
    }
    
    
    
}
