/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

/**
 *
 * @author Estudiantes
 */
public abstract class Figura implements iFigura {
    int Area;
    int Perimetro;
    Punto origen;
    Punto fin;

    public int getArea() {
        return Area;
    }


    public int getPerimetro() {
        return Perimetro;
    }


    public Punto getOrigen() {
        return origen;
    }

    public void setOrigen(Punto origen) {
        this.origen = origen;
    }

    public Punto getFin() {
        return fin;
    }

    public void setFin(Punto fin) {
        this.fin = fin;
    }

    @Override
    public String toString() {
        return "" + "Area=" + Area + ", Perimetro=" + Perimetro + ", origen=" + origen + ", fin=" + fin + '}';
    }
    
    
}
