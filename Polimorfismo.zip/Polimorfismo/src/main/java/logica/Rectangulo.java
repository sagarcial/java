/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

/**
 *
 * @author Estudiantes
 */
public class Rectangulo extends Figura {

    public void calcularArea() {
        Punto temp = new Punto(this.origen.x, this.fin.y);
        int base= this.fin.calcularDistancia(temp);
        int altura= this.origen.calcularDistancia(temp);
        this.Area=base*altura;
    }
    
     public void calcularPerimetro() {
        Punto temp = new Punto(this.origen.x, this.fin.y);
        int base= this.fin.calcularDistancia(temp);
        int altura= this.origen.calcularDistancia(temp);
        this.Perimetro=base*2+altura*2;
    }

    @Override
    public String toString() {
        return "Rectangulo{" + '}';
    }
    
     
}
