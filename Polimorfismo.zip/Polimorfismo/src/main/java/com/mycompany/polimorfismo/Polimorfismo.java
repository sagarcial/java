/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.polimorfismo;
import logica.*;
/**
 *
 * @author Estudiantes
 */
public class Polimorfismo {

    public static void main(String[] args) {
        Figura f = new Circulo();
        f.setOrigen(new Punto());
        f.setFin(new Punto(10,10));
        
        calcularPropiedadesFigura(f);
        
        System.out.println("area: "+ (f.getArea()));
        System.out.println("perimetro: "+ (f.getPerimetro()));
        
        
    }
    
   public static void calcularPropiedadesFigura(Figura f) {
       f.calcularArea();
       f.calcularPerimetro();
   }
           
}
